/* Description: It is used for Initialising home module
 * Author:  Pavithra
 * Created On: 20/11/2017
 * Modified For: 
 * Modified On:
 * Modified By:
 * */

(function () {
    'use strict';
    angular.module('app.home', ['app.core']);
})();
