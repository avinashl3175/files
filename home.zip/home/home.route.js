/* Description: The home Route deals with maintaining all routes related to home and their report pages.
 * Author:  Pavithra
 * Created On: 20/11/2017
 * Modified For: To Show Complete reports UI here
 * Modified On: 23/11/2017
 * Modified By:Chaitra
 * */

(function () {
    'use strict';
    angular
        .module('app.home')
        .run(appRun);
    appRun.$inject = ['routerHelper', '$rootScope'];
    /* @ngInject */
    function appRun(routerHelper, $rootScope) {
        routerHelper.configureStates(getStates());
    }

    //Function to register states
    function getStates() {
        return [
            {
                state: 'home',
                config: {
                    url: '/home',
                    title: 'Home',
                    metaTags: {
                        title: application_config.MetaData.Home.Title,
                        description: application_config.MetaData.Home.Description,
                        keywords: application_config.MetaData.Home.Keywords
                    },
                    settings: {
                        nav: 1,
                        roles: [],
                        userTypeCodes: [application_config.UserTypeCode_Admin, application_config.UserTypeCode_ClinicAdmin, application_config.UserTypeCode_ClinicManager, application_config.UserTypeCode_Provider, application_config.UserTypeCode_FrontOfficer],
                        parentState: "home",
                        parentTitle:""
                    },
                    views: {
                        'header': {
                            templateUrl: 'app/layout/header.html',
                            controller: 'Shell',
                            controllerAs: 'vm'
                        },                        
                        'content': {
                            templateUrl: 'app/home/home.index.html',
                            controller: 'Home',
                            controllerAs: 'vm'
                        },
                        'viewDetails': {
                            
                        },
                        'footer': {
                            templateUrl: 'app/layout/footer.html',
                            controller: '',
                            controllerAs: ''
                        }
                    }
                }
            }           
        ];
    }
})();
