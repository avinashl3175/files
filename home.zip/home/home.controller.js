/* Description: The Home Controller deals with maintaining functionality related to Home page.
 * Author:  Pavithra
 * Created On: 20/11/2017
 * Modified For: 
 * Modified On:
 * Modified By:
 * */

(function () {
    'use strict';

    angular
        .module('app.home')
        .controller('Home', Home);


    /* @ngInject */
    function Home($state, $scope, DTColumnDefBuilder, _, $log, $rootScope, $timeout, ServerSidePaginationService, store, HomeService, Enums, $window, UserService, $compile, $http) {
        // Global Variable Declaration
        var vm = this;
        application_config.preventNavigation = true;//Included to validate for back button click from from
        vm.FolderPath = application_config.FolderPath;
        vm.ReportSearchParams = {
            "IsSTAT" :false
        };
        //vm.ReportSearchParams ={"FirstName":"Lori","LastName":"Bailey","DOB":"07/22/1961","LocationCode":"Unavailable","ReportStatus":false,"IsSTAT":false};
        var loggedonuserinfo = store.get('loggedonuser');
        var userclinic = store.get('loggedonuserclinic'); //get loggedon user clinic code from local storage
        vm.LoadReportTable = false;
        //vm.LocationUrl = ($rootScope.IsAdmin ? "Location" : ("Location?where=" + '{"ClinicCode":{"contains":"' + userclinic + '"}}'));
        vm.LoadLocationDDL = true;
        vm.disablePrinted = true;
        vm.disableNew = true;

        //___________________________________________
        // For Datatable Search Input
        //___________________________________________
        /*
        vm.startSearch = function (query) {
            if (query != "" && query != undefined) {
                query = query.substr(0, 1).toUpperCase() + query.substr(1, query.length - 1);
                var request = {};
                request.RoleCode = {};
                request.RoleCode.    = application_config.RoleCode_Patient;
                if (query != undefined && query != "") {
                    var FReq = {};
                    FReq.FirstName = {};
                    FReq.FirstName.contains = query;
                    if (request.or == undefined) {
                        request.or = [];
                        request.or.push(FReq);
                    }
                    else {
                        request.or.push(FReq);
                    }
                }
                if (query != undefined && query != "") {
                    var LReq = {};
                    LReq.LastName = {};
                    LReq.LastName.contains = query;
                    if (request.or == undefined) {
                        request.or = [];
                        request.or.push(LReq);
                    }
                    else {
                        request.or.push(LReq);
                    }
                }
                if (vm.PatientReports.DateOfBirth != undefined && vm.PatientReports.DateOfBirth != "") {
                    var LDob = {};
                    LDob.DOB = (vm.PatientReports.DateOfBirth != "" ? moment(vm.PatientReports.DateOfBirth).format("YYYY-MM-DD") : "");
                    if (request.or == undefined) {
                        request.or = [];
                        request.or.push(LDob);
                    }
                    else {
                        request.or.push(LDob);
                    }
                }
                return HomeService.SearchPatient(encodeURIComponent(JSON.stringify(request))).then(function (res) {
                    var results = res.ViewModels;
                    var PatientCode = [];
                    results.forEach(function (item) {
                        PatientCode.push(item.Code);
                    });
                    var reportReq = {};
                    if (vm.PatientReports.ReportStatus !== "") {
                        reportReq.ReportStatus = vm.PatientReports.ReportStatus != undefined ? (vm.PatientReports.ReportStatus == false ? false : true) : false;
                    }
                    //Introduced to get STAT records in the search -- Starts
                    if (vm.PatientReports.STATStatus !== undefined) {
                        if (vm.PatientReports.STATStatus !== "" && vm.PatientReports.STATStatus !== false) {
                            reportReq.IsSTAT = true;
                        }
                    }
                    //Introduced to get STAT records in the search -- Ends
                    if (request.or != undefined) {
                        reportReq.PatientCode = PatientCode;
                    }
                    if ($rootScope.IsProvider && loggedonuserinfo != null) {
                        //reportReq.ProviderCode = loggedonuserinfo.Code;
                        if (vm.PatientReports.Location != undefined && vm.PatientReports.Location != "") {
                            UserService.GetUserClinicByLocationCode(vm.PatientReports.Location).then(function (res) {
                                if (res.Success) {
                                    var userClinic = res.ViewModels;
                                    var resArr = [];
                                    userClinic.forEach(function (item) {
                                        if (item.ReferenceNumber != null && item.ReferenceNumber != "") {
                                            resArr.push(item.ReferenceNumber);
                                        }
                                    });
                                    reportReq.ProviderCode = resArr;
                                    vm.SearchReports(reportReq);
                                }
                                else {
                                    vm.SearchReports(reportReq);
                                    $log.error('Error: ' + res.Message);
                                }
                            });
                        }
                        else {
                            var userclinic = store.get('loggedonuserclinic');
                            var userclinicLoc = store.get('loggedonusercliniclocations');
                            if (userclinic != null && userclinic != "") {
                                UserService.GetUserClinicByClinicCode(userclinic).then(function (res) {
                                    if (res.Success) {
                                        var userClinic = res.ViewModels;
                                        var resArr = [];
                                        userClinic.forEach(function (item) {
                                            if (item.ReferenceNumber != null && item.ReferenceNumber != "") {
                                                resArr.push(item.ReferenceNumber);
                                            }
                                        });
                                        reportReq.ProviderCode = resArr;
                                        vm.SearchReports(reportReq);
                                        //$log.info('Success: ' + application_config.Save_Success);
                                    }
                                    else {
                                        vm.SearchReports(reportReq);
                                        $log.error('Error: ' + res.Message);
                                    }
                                });
                            }
                            else {
                                UserService.GetUserClinicByUserCode(loggedonuserinfo.Code).then(function (res) {
                                    if (res.Success) {
                                        var userClinic = res.ViewModels;
                                        var resArr = [];
                                        userClinic.forEach(function (item) {
                                            if (item.ReferenceNumber != null && item.ReferenceNumber != "") {
                                                resArr.push(item.ReferenceNumber);
                                            }
                                        });
                                        reportReq.ProviderCode = resArr;
                                        vm.SearchReports(reportReq);
                                        //$log.info('Success: ' + application_config.Save_Success);
                                    }
                                    else {
                                        vm.SearchReports(reportReq);
                                        $log.error('Error: ' + res.Message);
                                    }
                                });
                            }
                        }
                    }
                    else if ($rootScope.IsClinicAdmin || $rootScope.IsClinicManager || $rootScope.IsFrontOfficer) {
                        var userclinic = store.get('loggedonuserclinic');
                        var userclinicLoc = store.get('loggedonusercliniclocations');
                        if (vm.PatientReports.Location != undefined && vm.PatientReports.Location != "") {
                            UserService.GetUserClinicByLocationCode(vm.PatientReports.Location).then(function (res) {
                                if (res.Success) {
                                    var userClinic = res.ViewModels;
                                    var resArr = [];
                                    userClinic.forEach(function (item) {
                                        if (item.ReferenceNumber != null && item.ReferenceNumber != "") {
                                            if (vm.PatientReports.Location != undefined && vm.PatientReports.Location != "") {
                                                if (item.Location == vm.PatientReports.Location) {
                                                    resArr.push(item.ReferenceNumber);
                                                }
                                            }
                                            else {
                                                resArr.push(item.ReferenceNumber);
                                            }
                                        }
                                    });
                                    reportReq.ProviderCode = resArr;
                                    vm.SearchReports(reportReq);
                                }
                                else {
                                    vm.SearchReports(reportReq);
                                    $log.error('Error: ' + res.Message);
                                }
                            });
                        } else {
                            if (userclinic != null && userclinic != "") {
                                UserService.GetUserClinicByClinicCode(userclinic).then(function (res) {
                                    if (res.Success) {
                                        var userClinic = res.ViewModels;
                                        var resArr = [];
                                        userClinic.forEach(function (item) {
                                            if (item.ReferenceNumber != null && item.ReferenceNumber != "") {
                                                if (vm.PatientReports.Location != undefined && vm.PatientReports.Location != "") {
                                                    if (item.Location == vm.PatientReports.Location) {
                                                        resArr.push(item.ReferenceNumber);
                                                    }
                                                }
                                                else {
                                                    resArr.push(item.ReferenceNumber);
                                                }
                                            }
                                        });
                                        reportReq.ProviderCode = resArr;
                                        vm.SearchReports(reportReq);
                                    }
                                    else {
                                        vm.SearchReports(reportReq);
                                        $log.error('Error: ' + res.Message);
                                    }
                                });
                            }
                            else {
                                vm.SearchReports(reportReq);
                            }
                        }
                    }
                    else if ($rootScope.IsAdmin) {
                        if (vm.PatientReports.Location != undefined && vm.PatientReports.Location != "") {
                            UserService.GetUserClinicByLocationCode(vm.PatientReports.Location).then(function (res) {
                                if (res.Success) {
                                    var userClinic = res.ViewModels;
                                    var resArr = [];
                                    userClinic.forEach(function (item) {
                                        if (item.ReferenceNumber != null && item.ReferenceNumber != "") {
                                            resArr.push(item.ReferenceNumber);
                                        }
                                    });
                                    reportReq.ProviderCode = resArr;
                                    vm.SearchReports(reportReq);
                                }
                                else {
                                    vm.SearchReports(reportReq);
                                    $log.error('Error: ' + res.Message);
                                }
                            });
                        }
                        else {
                            vm.SearchReports(reportReq);
                        }
                    }
                    else {
                        vm.SearchReports(reportReq);
                    }
                });
            }
            else
            {
                var reportReq = {};
                if (vm.PatientReports.ReportStatus !== "") {
                    reportReq.ReportStatus = vm.PatientReports.ReportStatus != undefined ? (vm.PatientReports.ReportStatus) : [false];
                }
                //Introduced to get STAT records in the search -- Starts
                if (vm.PatientReports.STATStatus !== undefined) {
                    if (vm.PatientReports.STATStatus !== "" && vm.PatientReports.STATStatus !== false) {
                        reportReq.IsSTAT = true;
                    }
                }
                //Introduced to get STAT records in the search -- Ends
                if ($rootScope.IsProvider && loggedonuserinfo != null) {
                    //reportReq.ProviderCode = loggedonuserinfo.Code;
                    UserService.GetUserClinicByUserCode(loggedonuserinfo.Code).then(function (res) {
                        if (res.Success) {
                            var userClinic = res.ViewModels;
                            var resArr = [];
                            userClinic.forEach(function (item) {
                                if (item.ReferenceNumber != null && item.ReferenceNumber != "") {
                                    resArr.push(item.ReferenceNumber);
                                }
                            });
                            reportReq.ProviderCode = resArr;
                            vm.SearchReports(reportReq);
                            //$log.info('Success: ' + application_config.Save_Success);
                        }
                        else {
                            vm.SearchReports(reportReq);
                            $log.error('Error: ' + res.Message);
                        }
                    });
                    //vm.SearchReports(reportReq);
                }
                else if ($rootScope.IsClinicAdmin || $rootScope.IsClinicManager || $rootScope.IsFrontOfficer) {
                    var userclinic = store.get('loggedonuserclinic');
                    var userclinicLoc = store.get('loggedonusercliniclocations');
                    if (null != userclinicLoc && userclinicLoc.length > 0) {
                        var userloc = userclinicLoc[0];
                    }
                    if (userclinic != null) {
                        UserService.GetUserClinicByLocationCode(userloc != null ? userloc : userclinic).then(function (res) {
                            if (res.Success) {
                                var userClinic = res.ViewModels;
                                var resArr = [];
                                userClinic.forEach(function (item) {
                                    if (item.ReferenceNumber != null && item.ReferenceNumber != "") {
                                        resArr.push(item.ReferenceNumber);
                                    }
                                });
                                reportReq.ProviderCode = resArr;
                                vm.SearchReports(reportReq);
                            }
                            else {
                                vm.SearchReports(reportReq);
                                $log.error('Error: ' + res.Message);
                            }
                        });
                    }
                    else {
                        vm.SearchReports(reportReq);
                    }
                }
                else {
                    vm.SearchReports(reportReq);
                }
            }
        }
        */

        //___________________________________________
        // Data Picker Initialization
        //___________________________________________
        vm.Reportdatedatepicker = function (args) {
            $('#' + args + ' input').datepicker({
                autoclose: true,
                format: 'mm/dd/yyyy',
                todayHighlight: true,
                endDate: '1d'
            });
            //var currentdate = moment(new Date()).format("MM/DD/YYYY");
            //$('#' + args + ' input').val(currentdate);

            $('#' + args + ' input').keyup(function (e) {
                if (e.keyCode != 8) {
                    if ($(this).val().length == 2 || $(this).val().length == 5) {
                        $(this).val($(this).val() + "/");
                    }
                }
            });
        }


        //-------------------------------------------------------
        //Function for Report radio button values
        //-------------------------------------------------------

        vm.ReportStatus = [{ "Name": "New", "Code": false },
        { "Name": "Completed", "Code": true }
        ];

        //_____________________________________________________
        //Function to initialze reports Data table
        //_____________________________________________________
        vm.initiateTableReports = function (params) {
            try {
                vm.LoadReportTable = false;
                // pagination starts
                // initializing the table
                vm.tblReportsDetails_pages = ServerSidePaginationService.paginationServiceParams().ssp_pages;
                ServerSidePaginationService.paginationServiceParams().paging.ssp_info.limit = 10;
                ServerSidePaginationService.paginationServiceParams().paging.ssp_info.isJsonRequest = false;
                var tableoptions = {};
                tableoptions.scrollx = false;
                tableoptions.TableName = 'tblReports';// expects the table id
                var sortableColumns = [5, 6, 7];
                ServerSidePaginationService.initializeTable(tableoptions, sortableColumns);
                vm.dtOptions = ServerSidePaginationService.paginationServiceParams().tableParams.dtOptions;
                //For removing sorting
                vm.dtColumnDefs = [
                    DTColumnDefBuilder.newColumnDef(0).notSortable(),
                    DTColumnDefBuilder.newColumnDef(1).notSortable(),
                    DTColumnDefBuilder.newColumnDef(2).notSortable(),
                    DTColumnDefBuilder.newColumnDef(3).notSortable(),
                    DTColumnDefBuilder.newColumnDef(4).notSortable(),
                    DTColumnDefBuilder.newColumnDef(5).withOption('type', 'date'),
                    //DTColumnDefBuilder.newColumnDef(6).notSortable(),
                ];
                //vm.dtColumnDefs = ServerSidePaginationService.paginationServiceParams().tableParams.dtColumnDefs;
                //To disable auto sorting
                vm.dtOptions.withOption('order', []);
                var request = {};
                var args = {};
                args.data = JSON.stringify(params);
                args.datasortBy = "CreatedAt desc";
                args.Url = "report";
                args.entity = "reports";
                args.dataSource = application_config.DataSource;
                ServerSidePaginationService.attachServerSidePagination(args);
            }
            catch (e) {
                console.log("Initiate Report tables Error" + e);
            }
        }

        //_____________________________________________________
        //Listener triggered after fetching result from pagination service
        //_____________________________________________________
        $rootScope.$$listeners['pagination_Result_reports'] = [];
        $rootScope.$on('pagination_Result_reports', function (event, args) {
            vm.tblReportsDetails_pagesinfo = args;
            vm.tblReportsDetails_pages = ServerSidePaginationService.paginationServiceParams().ssp_pages;
            vm.tblReportsDetails_pagesinfo = ServerSidePaginationService.paginationServiceParams().paging.ssp_info;
            //vm.tblReportsDetails_pages[vm.tblReportsDetails_pagesinfo.currentPage].result;
            var res = _.sortBy(vm.tblReportsDetails_pages[vm.tblReportsDetails_pagesinfo.currentPage].result, 'CreatedAt').reverse();
            var resArr = [];
            if (res.length > 0) {
                res.forEach(function (item) {
                    if (item.DecryptedHL7JSONData != undefined && item.DecryptedHL7JSONData != null && item.DecryptedHL7JSONData != "") {
                        var reportData = item.DecryptedHL7JSONData.MedicalReport != undefined ? item.DecryptedHL7JSONData.MedicalReport : {};
                        try {
                            reportData = (JSON.parse(reportData));
                        } catch (e) {
                            reportData = reportData;
                        }
                        //console.log(reportData.Storage);
                        var PatientDetails = reportData.Patient;
                        item.FirstName = PatientDetails.FirstName != undefined ? PatientDetails.FirstName : "";
                        item.MiddleName = PatientDetails.MiddleName != undefined ? PatientDetails.MiddleName : "";
                        item.LastName = PatientDetails.LastName != undefined ? PatientDetails.LastName : "";
                        item.CPT = reportData.CPTType != undefined ? (reportData.CPTType != "" ? reportData.CPTType : reportData.Exam) : reportData.Exam;
                        item.ReportDate = reportData.DictatedOn != undefined ? (moment(reportData.DictatedOn).format(application_config.DateFormat) == "Invalid date" ? moment().format(application_config.DateFormat) : moment(reportData.DictatedOn).format(application_config.DateFormat)) : moment().format(application_config.DateFormat);
                        item.DOB = PatientDetails.DOB != undefined ? (PatientDetails.DOB != "" ? moment(PatientDetails.DOB).format(application_config.DateFormat) : "") : "";
                        item.IsPrinted = item.ReportStatus ? "Completed" : "New";
                        item.IsPrintedColor = item.ReportStatus ? "grey" : "grey";
                        item.DataDocId = "11252";
                        item.LocationName = (item.ReportToLocation != "Unavailable" && item.ReportToLocation != null) ? item.ReportToLocation : "";
                        item.DocId = "85beeb68-512b-49b0-9e83-26c5e95eef5f";
                        //  Khris_Lee_ Abdomen sonogram. Complete_18Dec2017
                        var date = moment(reportData.DictatedOn).format("DDMMYYYY");
                        var fileName = (item.LastName).trim() + "_" + (item.FirstName).trim() + "_" + (reportData.CPTType != undefined ? reportData.CPTType : "").trim() + "_" + date.trim();
                        //Encrypt the Document key for security reason -- Starts
                        var encryptedFileUrl = CryptoJS.AES.encrypt(reportData.Storage != undefined ? item.StorageLink + "/" + fileName + ".pdf" : "", "");
                        item.DocURL = reportData.Storage != undefined ? encryptedFileUrl.toString() : "";
                        //With Time Stamp -- //Latest change in the report -- Timestamp has been included while creting report. 0n 7th-Mar-2018
                        var datetime = moment(reportData.DictatedOn).format("DDMMYYYYHHmmss");
                        var fileNamewithdateTime = (item.LastName).trim() + "_" + (item.FirstName).trim() + "_" + (reportData.CPTType != undefined ? reportData.CPTType : "").trim() + "_" + datetime.trim();
                        var encryptedFileUrlwithDateTime = CryptoJS.AES.encrypt(reportData.Storage != undefined ? item.StorageLink + "/" + fileNamewithdateTime + ".pdf" : "", "");
                        item.DocURLWithdateTime = reportData.Storage != undefined ? encryptedFileUrlwithDateTime.toString() : "";
                        //Encrypt the Document key for security reason -- Ends
                        //for json file download -- HL7 JSON data -- Starts
                        item.jsonfilename = fileName + ".hl7";
                        item.pdffilename = fileName + ".pdf";
                        item.pdffilenameWithDateTime = fileNamewithdateTime + ".pdf";
                        //for json file download -- HL7 JSON data -- Ends                        
                    }
                    resArr.push(item);
                });
                vm.SortedResult = resArr;
            }
            else {
                vm.SortedResult = [];
            }
            vm.LoadReportTable = true;
            vm.disablePrinted = true;
            vm.disableNew = true;
            angular.element("#NewReport").addClass('disabled');
            angular.element("#PrintedReport").addClass('disabled');
            angular.element('tr.Completed').children().find('input').removeAttr('disabled');
            angular.element('tr.New').children().find('input').removeAttr('disabled');
        });

        //_____________________________________________________
        //Listener to show the loading bar on success
        //_____________________________________________________
        $rootScope.$$listeners['pagination_AddLoadingProgress_reports'] = [];
        $rootScope.$on('pagination_AddLoadingProgress_reports', function (event, args) {
            //Adding progress bar
            if (!$("#divReportsTableDataGrid").hasClass('ng-hide')){
                $rootScope.$broadcast('showLoadProgressBar', { progress: "show", container: "divReportsGrid" });
                $("#divReportsTableDataGrid").addClass("ng-hide");
                // angular.element('#loading-overlay').hide();            
            }
        });

        //_____________________________________________________
        //Listener to hide the loading bar on success
        //_____________________________________________________
        $rootScope.$$listeners['pagination_RemoveLoadingProgress_reports'] = [];
        $rootScope.$on('pagination_RemoveLoadingProgress_reports', function (event, args) {
            //Removing progress bar
            $rootScope.$broadcast('showLoadProgressBar', { progress: "hide", container: "divReportsGrid" });
            $("#divReportsTableDataGrid").removeClass("ng-hide");
            // angular.element('#loading-overlay').show();
        });

        //vm.viewer = function () {
        //    $("#modalMedicalRecordForm").modal({ backdrop: 'static' });
        //}

        //Function to download patient report pdf
        vm.DownloadReport = function (url, ele, filename, urlwithDateTime, filenamewithdateTime) {
            var request = {};
            request.KeyName = urlwithDateTime;//Latest change in the report -- Timestamp has been included while creting report. 0n 7th-Mar-2018
            HomeService.RetrieveDocument(JSON.stringify(request)).then(function (res) {
                var element = ele;
                if (res.Success) {
                    //If response is succes , check if ArrayBuffer exists in the output. If so Create Blob using the buffer
                    if (res.ArrayBuffer != undefined && res.ArrayBuffer.Body != undefined && res.ArrayBuffer.Body.data != undefined) {
                        var file = new Blob([new Uint8Array(res.ArrayBuffer.Body.data)], { type: 'application/pdf' });// creating blob data
                        var fileURL = URL.createObjectURL(file); //Get blob url
                        $(element.currentTarget).next().attr('download', filenamewithdateTime).attr('href', fileURL);
                        $timeout(function () {
                            //fix for IE and Chrome and mozilla
                            var isChromium = window.chrome, vendorName = window.navigator.vendor,
                                isOpera = window.navigator.userAgent.indexOf("OPR") > -1,
                                isFirefox = window.navigator.userAgent.indexOf("Firefox") > -1,
                                isIEedge = window.navigator.userAgent.indexOf("Edge") > -1;
                            if (isChromium !== null && isChromium !== undefined && vendorName === "Google Inc." && isOpera == false && isIEedge == false && isFirefox == false) {
                                $(element.currentTarget).next()[0].click();
                            }
                            else if (isFirefox) {
                                $(element.currentTarget).next()[0].click();
                            }
                            else {
                                window.navigator.msSaveBlob(file, filenamewithdateTime);
                            }
                        }, 10);
                        $timeout(function () {
                            //clearing the downloaded path after click event been triggered(after document download) //For security purpose
                            $(element.currentTarget).next().attr('download', "").attr('href', "");
                            window.URL.revokeObjectURL(fileURL);
                        }, 100);
                    }
                    else {
                        toastr.error("Failed to retrive document.");
                    }
                }
                else {
                    var request = {};
                    request.KeyName = url; //Old report without timestamp -- 0n 7th-Mar-2018
                    HomeService.RetrieveDocument(JSON.stringify(request)).then(function (res) {
                        var element = ele;
                        if (res.Success) {
                            //If response is succes , check if ArrayBuffer exists in the output. If so Create Blob using the buffer
                            if (res.ArrayBuffer != undefined && res.ArrayBuffer.Body != undefined && res.ArrayBuffer.Body.data != undefined) {
                                var file = new Blob([new Uint8Array(res.ArrayBuffer.Body.data)], { type: 'application/pdf' });// creating blob data
                                var fileURL = URL.createObjectURL(file); //Get blob url
                                $(element.currentTarget).next().attr('download', filename).attr('href', fileURL);
                                $timeout(function () {
                                    //fix for IE and Chrome and mozilla
                                    var isChromium = window.chrome, vendorName = window.navigator.vendor,
                                        isOpera = window.navigator.userAgent.indexOf("OPR") > -1,
                                        isFirefox = window.navigator.userAgent.indexOf("Firefox") > -1,
                                        isIEedge = window.navigator.userAgent.indexOf("Edge") > -1;
                                    if (isChromium !== null && isChromium !== undefined && vendorName === "Google Inc." && isOpera == false && isIEedge == false && isFirefox == false) {
                                        $(element.currentTarget).next()[0].click();
                                    }
                                    else if (isFirefox) {
                                        $(element.currentTarget).next()[0].click();
                                    }
                                    else {
                                        window.navigator.msSaveBlob(file, filename);
                                    }
                                }, 10);
                                $timeout(function () {
                                    //clearing the downloaded path after click event been triggered(after document download) //For security purpose
                                    $(element.currentTarget).next().attr('download', "").attr('href', "");
                                    window.URL.revokeObjectURL(fileURL);
                                }, 100);
                            }
                            else {
                                toastr.error("Failed to retrive document.");
                            }
                        }
                        else{
                            toastr.error("Report not available.");
                        }
                    });
                }
            });
        }

        //Function to download patient hl7 data
        vm.DownloadHL7Data = function (content, filename, ele) {
            var element = ele;
            //var content = item.DecryptedHL7;
            var blob = new Blob([content], { type: 'application/json' });
            var url = URL.createObjectURL(blob);
            $(element.currentTarget).next().attr('download', filename).attr('href', url);
            $timeout(function () {
                //fix for IE and Chrome and mozilla
                var isChromium = window.chrome, vendorName = window.navigator.vendor,
                    isOpera = window.navigator.userAgent.indexOf("OPR") > -1,
                    isFirefox = window.navigator.userAgent.indexOf("Firefox") > -1,
                    isIEedge = window.navigator.userAgent.indexOf("Edge") > -1;
                if (isChromium !== null && isChromium !== undefined && vendorName === "Google Inc." && isOpera == false && isIEedge == false && isFirefox == false) {
                    $(element.currentTarget).next()[0].click();
                }
                else if (isFirefox) {
                    $(element.currentTarget).next()[0].click();
                }
                else {
                    window.navigator.msSaveBlob(blob, filename);
                }
            }, 10);
            $timeout(function () {
                //clearing the downloaded path after click event been triggered(after document download) //For security purpose
                $(element.currentTarget).next().attr('download', "").attr('href', "");
                window.URL.revokeObjectURL(url);
            }, 100);
        }

        //vm.selectSingle = function (data, type, index, event) {
        //    if (type) {
        //        if (data.IsPrinted == "New")
        //            angular.element("#PrintedReport").removeAttr('disabled');
        //        else
        //            angular.element("#NewReport").removeAttr('disabled');
        //    }
        //    else {
        //        angular.element("#PrintedReport").attr('disabled', 'disabled');
        //        angular.element("#NewReport").attr('disabled', 'disabled');
        //    }
        //    return false;
        //}

        //vm.selectSinglecheck = function (data, status) {
        //    if (status) {
        //        if (data.IsPrinted == "New") {
        //            angular.element("#PrintedReport").removeAttr('disabled');
        //        }
        //        else {
        //            angular.element("#NewReport").removeAttr('disabled');
        //        }
        //    }
        //}

        vm.selectSingle = function (data, type, index, event) {
            if (type) {
                if (data.IsPrinted == "New") {
                    angular.element('tr.Completed').children().find('input').attr('disabled', 'disabled');
                    vm.disablePrinted = false;
                    angular.element("#PrintedReport").removeClass('disabled');
                }
                else {
                    angular.element('tr.New').children().find('input').attr('disabled', 'disabled');
                    vm.disableNew = false;
                    angular.element("#NewReport").removeClass('disabled');
                }
            }
            else {
                if (data.IsPrinted == "New") {
                    //for enabling the checkboxes on unchecking
                    var recLen = angular.element('input.false.helensys-dummy-reportstatus:checked').length;
                    if (recLen == 0) {
                        angular.element('tr.Completed').children().find('input').removeAttr('disabled');
                        vm.disablePrinted = true;
                        angular.element("#PrintedReport").addClass('disabled');
                    }
                }
                else {
                    //for enabling the checkboxes on unchecking
                    var recLen = angular.element('input.true.helensys-dummy-reportstatus:checked').length;
                    if (recLen == 0) {
                        angular.element('tr.New').children().find('input').removeAttr('disabled');
                        vm.disableNew = true;
                        angular.element("#NewReport").addClass('disabled');
                    }
                }
            }
            return false;
        }

        vm.selectSinglecheck = function (data, status) {
            if (status) {
                if (data.IsPrinted == "New") {
                    angular.element('tr.Completed').children().find('input').attr('disabled', 'disabled');
                    vm.disablePrinted = false;
                }
                else {
                    angular.element('tr.New').children().find('input').attr('disabled', 'disabled');
                    vm.disableNew = false;
                }
            }
        }

        /*
        vm.SearchReports = function (request) {
            vm.initiateTableReports(request);
        }

        
        vm.SearchPatientReports = function (data) {
            $timeout(function () {
                if ((data.FirstName == undefined || data.FirstName == "") && (data.LastName == undefined || data.LastName == "") && (data.DateOfBirth == undefined || data.DateOfBirth == "") && (data.Location == undefined || data.Location == "")) {
                    var reportReq = {};
                    if (data.ReportStatus !== "") {
                        reportReq.ReportStatus = data.ReportStatus != undefined ? (data.ReportStatus) : [false];
                    }
                    //Introduced to get STAT records in the search -- Starts
                    if (data.STATStatus !== undefined) {
                        if (data.STATStatus !== "" && data.STATStatus !== false) {
                            reportReq.IsSTAT = true;
                        }
                    }
                    //Introduced to get STAT records in the search -- Ends
                    if ($rootScope.IsProvider && loggedonuserinfo != null) {
                        //reportReq.ProviderCode = loggedonuserinfo.Code;
                        UserService.GetUserClinicByUserCode(loggedonuserinfo.Code).then(function (res) {
                            if (res.Success) {
                                var userClinic = res.ViewModels;
                                var resArr = [];
                                userClinic.forEach(function (item) {
                                    if (item.ReferenceNumber != null && item.ReferenceNumber != "") {
                                        resArr.push(item.ReferenceNumber);
                                    }
                                });
                                reportReq.ProviderCode = resArr;
                                vm.SearchReports(reportReq);
                                //$log.info('Success: ' + application_config.Save_Success);
                            }
                            else {
                                vm.SearchReports(reportReq);
                                $log.error('Error: ' + res.Message);
                            }
                        });
                        //vm.SearchReports(reportReq);
                    }
                    else if ($rootScope.IsClinicAdmin || $rootScope.IsClinicManager || $rootScope.IsFrontOfficer) {
                        var userclinic = store.get('loggedonuserclinic');
                        var userclinicLoc = store.get('loggedonusercliniclocations');
                        if (null != userclinicLoc && userclinicLoc.length > 0) {
                            var userloc = userclinicLoc[0];
                        }
                        if (userclinic != null) {
                            UserService.GetUserClinicByLocationCode(userloc != null ? userloc : userclinic).then(function (res) {
                                if (res.Success) {
                                    var userClinic = res.ViewModels;
                                    var resArr = [];
                                    userClinic.forEach(function (item) {
                                        if (item.ReferenceNumber != null && item.ReferenceNumber != "") {
                                            resArr.push(item.ReferenceNumber);
                                        }
                                    });
                                    reportReq.ProviderCode = resArr;
                                    vm.SearchReports(reportReq);
                                }
                                else {
                                    vm.SearchReports(reportReq);
                                    $log.error('Error: ' + res.Message);
                                }
                            });
                        }
                        else {
                            vm.SearchReports(reportReq);
                        }
                    }
                    else {
                        vm.SearchReports(reportReq);
                    }
                }
                else {
                    var request = {};
                    request.RoleCode = {};
                    request.RoleCode.contains = application_config.RoleCode_Patient;
                    if (data.FirstName != undefined && data.FirstName != "") {
                        //converting to uppercase
                        var fName = data.FirstName.substr(0, 1).toUpperCase() + data.FirstName.substr(1, data.FirstName.length - 1);
                        request.FirstName = {};
                        request.FirstName.contains = fName;
                    }
                    if (data.LastName != undefined && data.LastName != "") {
                        //converting to uppercase
                        var lName = data.LastName.substr(0, 1).toUpperCase() + data.LastName.substr(1, data.LastName.length - 1);
                        request.LastName = {};
                        request.LastName.contains = lName;
                    }
                    if (data.DateOfBirth != undefined && data.DateOfBirth != "") {
                        request.DOB = (data.DateOfBirth != "" ? moment(data.DateOfBirth).format("YYYY-MM-DD") : "");
                    }
                    if ((data.FirstName != undefined && data.FirstName != "") || (data.LastName != undefined && data.LastName != "") || (data.DateOfBirth != undefined && data.DateOfBirth != "")) {
                        return HomeService.SearchPatient(encodeURIComponent(JSON.stringify(request))).then(function (res) {
                            var results = res.ViewModels;
                            var PatientCode = [];
                            results.forEach(function (item) {
                                PatientCode.push(item.Code);
                            });
                            var reportReq = {};
                            if (data.ReportStatus !== "") {
                                reportReq.ReportStatus = data.ReportStatus != undefined ? (data.ReportStatus == false ? false : true) : false;
                            }
                            //Introduced to get STAT records in the search -- Starts
                            if (data.STATStatus !== undefined) {
                                if (data.STATStatus !== "" && data.STATStatus !== false) {
                                    reportReq.IsSTAT = true;
                                }
                            }
                            //Introduced to get STAT records in the search -- Ends
                            if ((data.FirstName != undefined && data.FirstName != "") || (data.LastName != undefined && data.LastName != "") || (data.DateOfBirth != undefined && data.DateOfBirth != "")) {
                                reportReq.PatientCode = PatientCode;
                            }
                            if ($rootScope.IsProvider && loggedonuserinfo != null) {
                                //reportReq.ProviderCode = loggedonuserinfo.Code;
                                if (data.Location != undefined && data.Location != "") {
                                    UserService.GetUserClinicByLocationCode(data.Location).then(function (res) {
                                        if (res.Success) {
                                            var userClinic = res.ViewModels;
                                            var resArr = [];
                                            userClinic.forEach(function (item) {
                                                if (item.ReferenceNumber != null && item.ReferenceNumber != "") {
                                                    resArr.push(item.ReferenceNumber);
                                                }
                                            });
                                            reportReq.ProviderCode = resArr;
                                            vm.SearchReports(reportReq);
                                        }
                                        else {
                                            vm.SearchReports(reportReq);
                                            $log.error('Error: ' + res.Message);
                                        }
                                    });
                                }
                                else {
                                    var userclinic = store.get('loggedonuserclinic');
                                    var userclinicLoc = store.get('loggedonusercliniclocations');
                                    if (userclinic != null && userclinic != "") {
                                        UserService.GetUserClinicByClinicCode(userclinic).then(function (res) {
                                            if (res.Success) {
                                                var userClinic = res.ViewModels;
                                                var resArr = [];
                                                userClinic.forEach(function (item) {
                                                    if (item.ReferenceNumber != null && item.ReferenceNumber != "") {
                                                        resArr.push(item.ReferenceNumber);
                                                    }
                                                });
                                                reportReq.ProviderCode = resArr;
                                                vm.SearchReports(reportReq);
                                                //$log.info('Success: ' + application_config.Save_Success);
                                            }
                                            else {
                                                vm.SearchReports(reportReq);
                                                $log.error('Error: ' + res.Message);
                                            }
                                        });
                                    }
                                    else {
                                        UserService.GetUserClinicByUserCode(loggedonuserinfo.Code).then(function (res) {
                                            if (res.Success) {
                                                var userClinic = res.ViewModels;
                                                var resArr = [];
                                                userClinic.forEach(function (item) {
                                                    if (item.ReferenceNumber != null && item.ReferenceNumber != "") {
                                                        resArr.push(item.ReferenceNumber);
                                                    }
                                                });
                                                reportReq.ProviderCode = resArr;
                                                vm.SearchReports(reportReq);
                                                //$log.info('Success: ' + application_config.Save_Success);
                                            }
                                            else {
                                                vm.SearchReports(reportReq);
                                                $log.error('Error: ' + res.Message);
                                            }
                                        });
                                    }
                                }
                            }
                            else if ($rootScope.IsClinicAdmin || $rootScope.IsClinicManager || $rootScope.IsFrontOfficer) {
                                var userclinic = store.get('loggedonuserclinic');
                                var userclinicLoc = store.get('loggedonusercliniclocations');
                                if (data.Location != undefined && data.Location != "") {
                                    UserService.GetUserClinicByLocationCode(data.Location).then(function (res) {
                                        if (res.Success) {
                                            var userClinic = res.ViewModels;
                                            var resArr = [];
                                            userClinic.forEach(function (item) {
                                                if (item.ReferenceNumber != null && item.ReferenceNumber != "") {
                                                    if (data.Location != undefined && data.Location != "") {
                                                        if (item.Location == data.Location) {
                                                            resArr.push(item.ReferenceNumber);
                                                        }
                                                    }
                                                    else {
                                                        resArr.push(item.ReferenceNumber);
                                                    }
                                                }
                                            });
                                            reportReq.ProviderCode = resArr;
                                            vm.SearchReports(reportReq);
                                        }
                                        else {
                                            vm.SearchReports(reportReq);
                                            $log.error('Error: ' + res.Message);
                                        }
                                    });
                                } else {
                                    if (userclinic != null && userclinic != "") {
                                        UserService.GetUserClinicByClinicCode(userclinic).then(function (res) {
                                            if (res.Success) {
                                                var userClinic = res.ViewModels;
                                                var resArr = [];
                                                userClinic.forEach(function (item) {
                                                    if (item.ReferenceNumber != null && item.ReferenceNumber != "") {
                                                        if (data.Location != undefined && data.Location != "") {
                                                            if (item.Location == data.Location) {
                                                                resArr.push(item.ReferenceNumber);
                                                            }
                                                        }
                                                        else {
                                                            resArr.push(item.ReferenceNumber);
                                                        }
                                                    }
                                                });
                                                reportReq.ProviderCode = resArr;
                                                vm.SearchReports(reportReq);
                                            }
                                            else {
                                                vm.SearchReports(reportReq);
                                                $log.error('Error: ' + res.Message);
                                            }
                                        });
                                    }
                                    else {
                                        vm.SearchReports(reportReq);
                                    }
                                }
                            }
                            else if ($rootScope.IsAdmin) {
                                if (data.Location != undefined && data.Location != "") {
                                    UserService.GetUserClinicByLocationCode(data.Location).then(function (res) {
                                        if (res.Success) {
                                            var userClinic = res.ViewModels;
                                            var resArr = [];
                                            userClinic.forEach(function (item) {
                                                if (item.ReferenceNumber != null && item.ReferenceNumber != "") {
                                                    resArr.push(item.ReferenceNumber);
                                                }
                                            });
                                            reportReq.ProviderCode = resArr;
                                            vm.SearchReports(reportReq);
                                        }
                                        else {
                                            vm.SearchReports(reportReq);
                                            $log.error('Error: ' + res.Message);
                                        }
                                    });
                                }
                                else {
                                    vm.SearchReports(reportReq);
                                }
                            }
                            else {
                                vm.SearchReports(reportReq);
                            }
                        });
                    }
                    else
                    {
                        var reportReq = {};
                        if (data.ReportStatus !== "") {
                            reportReq.ReportStatus = data.ReportStatus != undefined ? (data.ReportStatus == false ? false : true) : false;
                        }
                        //Introduced to get STAT records in the search -- Starts
                        if (data.STATStatus !== undefined) {
                            if (data.STATStatus !== "" && data.STATStatus !== false) {
                                reportReq.IsSTAT = true;
                            }
                        }
                        //Introduced to get STAT records in the search -- Ends
                        if ($rootScope.IsProvider && loggedonuserinfo != null) {
                            //reportReq.ProviderCode = loggedonuserinfo.Code;
                            if (data.Location != undefined && data.Location != "") {
                                UserService.GetUserClinicByLocationCode(data.Location).then(function (res) {
                                    if (res.Success) {
                                        var userClinic = res.ViewModels;
                                        var resArr = [];
                                        userClinic.forEach(function (item) {
                                            if (item.ReferenceNumber != null && item.ReferenceNumber != "") {
                                                resArr.push(item.ReferenceNumber);
                                            }
                                        });
                                        reportReq.ProviderCode = resArr;
                                        vm.SearchReports(reportReq);
                                    }
                                    else {
                                        vm.SearchReports(reportReq);
                                        $log.error('Error: ' + res.Message);
                                    }
                                });
                            }
                            else {
                                var userclinic = store.get('loggedonuserclinic');
                                var userclinicLoc = store.get('loggedonusercliniclocations');
                                if (userclinic != null && userclinic != "") {
                                    UserService.GetUserClinicByClinicCode(userclinic).then(function (res) {
                                        if (res.Success) {
                                            var userClinic = res.ViewModels;
                                            var resArr = [];
                                            userClinic.forEach(function (item) {
                                                if (item.ReferenceNumber != null && item.ReferenceNumber != "") {
                                                    resArr.push(item.ReferenceNumber);
                                                }
                                            });
                                            reportReq.ProviderCode = resArr;
                                            vm.SearchReports(reportReq);
                                            //$log.info('Success: ' + application_config.Save_Success);
                                        }
                                        else {
                                            vm.SearchReports(reportReq);
                                            $log.error('Error: ' + res.Message);
                                        }
                                    });
                                }
                                else {
                                    UserService.GetUserClinicByUserCode(loggedonuserinfo.Code).then(function (res) {
                                        if (res.Success) {
                                            var userClinic = res.ViewModels;
                                            var resArr = [];
                                            userClinic.forEach(function (item) {
                                                if (item.ReferenceNumber != null && item.ReferenceNumber != "") {
                                                    resArr.push(item.ReferenceNumber);
                                                }
                                            });
                                            reportReq.ProviderCode = resArr;
                                            vm.SearchReports(reportReq);
                                            //$log.info('Success: ' + application_config.Save_Success);
                                        }
                                        else {
                                            vm.SearchReports(reportReq);
                                            $log.error('Error: ' + res.Message);
                                        }
                                    });
                                }
                            }
                        }
                        else if ($rootScope.IsClinicAdmin || $rootScope.IsClinicManager || $rootScope.IsFrontOfficer) {
                            var userclinic = store.get('loggedonuserclinic');
                            var userclinicLoc = store.get('loggedonusercliniclocations');
                            if (data.Location != undefined && data.Location != "") {
                                UserService.GetUserClinicByLocationCode(data.Location).then(function (res) {
                                    if (res.Success) {
                                        var userClinic = res.ViewModels;
                                        var resArr = [];
                                        userClinic.forEach(function (item) {
                                            if (item.ReferenceNumber != null && item.ReferenceNumber != "") {
                                                if (data.Location != undefined && data.Location != "") {
                                                    if (item.Location == data.Location) {
                                                        resArr.push(item.ReferenceNumber);
                                                    }
                                                }
                                                else {
                                                    resArr.push(item.ReferenceNumber);
                                                }
                                            }
                                        });
                                        reportReq.ProviderCode = resArr;
                                        vm.SearchReports(reportReq);
                                    }
                                    else {
                                        vm.SearchReports(reportReq);
                                        $log.error('Error: ' + res.Message);
                                    }
                                });
                            } else {
                                if (userclinic != null && userclinic != "") {
                                    UserService.GetUserClinicByClinicCode(userclinic).then(function (res) {
                                        if (res.Success) {
                                            var userClinic = res.ViewModels;
                                            var resArr = [];
                                            userClinic.forEach(function (item) {
                                                if (item.ReferenceNumber != null && item.ReferenceNumber != "") {
                                                    if (data.Location != undefined && data.Location != "") {
                                                        if (item.Location == data.Location) {
                                                            resArr.push(item.ReferenceNumber);
                                                        }
                                                    }
                                                    else {
                                                        resArr.push(item.ReferenceNumber);
                                                    }
                                                }
                                            });
                                            reportReq.ProviderCode = resArr;
                                            vm.SearchReports(reportReq);
                                        }
                                        else {
                                            vm.SearchReports(reportReq);
                                            $log.error('Error: ' + res.Message);
                                        }
                                    });
                                }
                                else {
                                    vm.SearchReports(reportReq);
                                }
                            }
                        }
                        else if ($rootScope.IsAdmin) {
                            if (data.Location != undefined && data.Location != "") {
                                UserService.GetUserClinicByLocationCode(data.Location).then(function (res) {
                                    if (res.Success) {
                                        var userClinic = res.ViewModels;
                                        var resArr = [];
                                        userClinic.forEach(function (item) {
                                            if (item.ReferenceNumber != null && item.ReferenceNumber != "") {
                                                resArr.push(item.ReferenceNumber);
                                            }
                                        });
                                        reportReq.ProviderCode = resArr;
                                        vm.SearchReports(reportReq);
                                    }
                                    else {
                                        vm.SearchReports(reportReq);
                                        $log.error('Error: ' + res.Message);
                                    }
                                });
                            }
                            else {
                                vm.SearchReports(reportReq);
                            }
                        }
                        else {
                            vm.SearchReports(reportReq);
                        }
                    }
                    
                }
            }, 500);
        }

        vm.SetReportStatus = function (type, inputtype, ele) {
            var request = {};
            if (type == "New") {
                request.ReportStatus = false;
                var recLen = angular.element('input.true.helensys-dummy-reportstatus:checked').length;
                var records = angular.element('input.true.helensys-dummy-reportstatus:checked');
            }
            else {
                request.ReportStatus = true;
                var recLen = angular.element('input.false.helensys-dummy-reportstatus:checked').length;
                var records = angular.element('input.false.helensys-dummy-reportstatus:checked');
            }
            //if (inputtype == "checkbox") {
            //    var recLen = angular.element('input.helensys-dummy-reportstatus:checked').length;
            //    var records = angular.element('input.helensys-dummy-reportstatus:checked');
            //}
            //else {
            //    var recLen = $(ele.currentTarget).length;
            //    var records = $(ele.currentTarget);
            //}
            var count = 0;
            records.each(function (i, item) {
                HomeService.UpdateReport(request, $(item).attr('data-reportid')).then(function (res) {
                    count++;
                    if (res.Status != undefined) {
                        if (recLen == count) {
                            vm.SearchPatientReports(vm.PatientReports);
                            toastr.success(application_config.Save_Success);
                        }
                        $log.info('Success: ' + application_config.Save_Success);
                    }
                    else {
                        toastr.error(res.Message);
                        $log.error('Error: ' + res.Message);
                    }
                });
            });
        }
        */

        /*
         Comment: Avinash Code Starts
        */

        //_____________________________________________________
        //Subscribing Event on change of location:
        //_____________________________________________________
        /*
        $rootScope.$$listeners.cboPatientReportsLocation__OnSelectEvent = [];
        $rootScope.$on('cboPatientReportsLocation_OnSelectEvent', function (event, args) {
            if (args && args.Code) {
                const query = "Location=" + args.Code;
                return HomeService.GetUserClinic(query).then(function (res) {
                    if (res.Success && res.ViewModels.length > 0) {
                        let ProviderCodes = [];
                        res.ViewModels.forEach(function (item) {
                            if (item.ReferenceNumber != null && item.ReferenceNumber != "") {
                                ProviderCodes.push(item.ReferenceNumber);
                            }
                        });
                        vm.ReportSearchParams.ProviderCode = ProviderCodes;
                    }
                });
            }
        });
        */

        vm.GetUserClinicRecord = (params = {}, method) => {
            if (params) {
                //adding progress bar for the report search datatable
                $rootScope.$broadcast('showLoadProgressBar', { progress: "show", container: "divReportsGrid" });
                $("#divReportsTableDataGrid").addClass("ng-hide");
                UserService[method](params).then(function (res) {
                    if (res.Success) {
                        let userClinic = res.ViewModels;
                        let resArr = [];
                        userClinic.forEach(function (item) {
                            if (item.ReferenceNumber != null && item.ReferenceNumber != "") {
                                resArr.push(item.ReferenceNumber);
                            }
                        });
                        vm.ReportSearchParams.ProviderCode = resArr;
                        vm.initiateTableReports(vm.ReportSearchParams);
                    }
                    else {
                        vm.initiateTableReports(vm.ReportSearchParams);
                        $log.error('Error: ' + res.Message);
                    }
                });
            }
            else {
                vm.initiateTableReports(vm.ReportSearchParams);
            }
        }

        vm.formReportSearchReq = (params) => {
            let reportReq = {};
            params.DOB = ((params.DOB) ? moment(params.DOB).format("YYYY-MM-DD") : "");
            if ($rootScope.IsProvider && loggedonuserinfo != null) {
                vm.GetUserClinicRecord(loggedonuserinfo.Code, "GetUserClinicByUserCode");
            }
            else if ($rootScope.IsClinicAdmin || $rootScope.IsClinicManager || $rootScope.IsFrontOfficer) {
                let userclinic = store.get('loggedonuserclinic');
                let userclinicLoc = store.get('loggedonusercliniclocations');
                let userloc;
                if (null != userclinicLoc && userclinicLoc.length > 0) {
                    userloc = userclinicLoc[0];
                }
                if (userclinic != null) {
                    const reqObj = userloc != null ? userloc : userclinic;
                    vm.GetUserClinicRecord(reqObj, "GetUserClinicByLocationCode");
                }
            }            
            else if ($rootScope.IsAdmin) {
                if (vm.SelectedLocationCode != undefined && vm.SelectedLocationCode != "") {
                    vm.GetUserClinicRecord(vm.SelectedLocationCode, "GetUserClinicByLocationCode");
                }
                else {
                    vm.initiateTableReports(reportReq);
                }
            }
        }
    }
})();
